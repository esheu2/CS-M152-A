case.py: Python script for generating sigmoid LUT.
iris.data: Iris flower data and labels.
nn_iris.py: Python neural network script.
weights.txt: Weights from the neural network.